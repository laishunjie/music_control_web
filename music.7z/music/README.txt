1.下载安装PHP8.1以上并部署
2.导入到apache
3.当前文件夹运行php -S IP:8090 server.php
4.浏览器运行http://IP/music/remote.html
上一曲: Ctrl + ←
下一曲: Ctrl + →
播放/暂停: Ctrl + ↓
音量增加:Ctrl+F4（bug）
音量减少:Ctrl+F6（bug）

